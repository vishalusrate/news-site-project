<html>
<head><title>no directery</title>
</head>
<body>
<h1> no such path available</h1>
<a href="http://localhost/news-site/news-template/">HOME PAGE</a>

</body>
</html>