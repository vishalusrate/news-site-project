<?php
$hostname ="http://localhost/news-site/news-template";
$conn = mysqli_connect("localhost","root","","news-site") or die("connection problem check ineternet connection".mysqli_connect_error());


?>